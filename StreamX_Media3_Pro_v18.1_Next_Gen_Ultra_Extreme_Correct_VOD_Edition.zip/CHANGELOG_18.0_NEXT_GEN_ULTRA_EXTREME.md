# Changelog — StreamX Media3 Pro v18.0 (Next-Generation Ultra Extreme Edition)

## 1. Base & Absolute Project Preservation
- Built directly on the supplied **v17.0 Ultra Extreme Edition** project (`com.harindra.iptvpro`, `versionCode = 180`, `versionName = "18.0"`).
- Preserved all 44 existing layout IDs in `activity_player.xml`, all 48 existing drawable XML resources, Media3 1.11.1 Direct-RAM playback configuration (`forceEnableMediaCodecAsynchronousQueueing`, `SeekParameters.CLOSEST_SYNC`, `ERROR_CODE_BEHIND_LIVE_WINDOW` live-edge recovery), `StreamPreFetcher` (`PreloadAwareDataSource`, 64KB manifest + 96KB initial segment prefix in a 320KB RAM LRU), `ChannelCacheStore` (`SXB2` line-binary cache with 80-channel progressive first batch), `XmltvParser` + `EpgCacheStore`, `XtreamRepository` (`.m3u8` primary + `.ts` alternate backup URL pairing, 2-attempt transient retry, container extension sanitization), `ProfileStore` (AES-256-GCM encrypted credentials + salted SHA-256 parental PIN), `BootReceiver`, and `StreamXApp` 512MB low-memory callbacks.

## 2. Three Primary Entertainment Sections (`LIVE TV` • `MOVIES` • `SERIES`)
- Added dedicated primary navigation buttons in `activity_player.xml` (`btnSectionLiveTv`, `btnSectionMovies`, `btnSectionSeries`) and full-screen **4D Movies & Series Poster Grid Hub** (`vodPosterGridPanel`).
- Added `MediaCatalogEngine` in `Models.kt` to classify Live TV, Movies, and Series from provider categories, stream URLs, and titles without fabricating categories or entries.

## 3. Advanced Movies Library & 6-Column TV Poster Grid
- Implemented `VodPosterGridAdapter` using a responsive `GridLayoutManager` (6 columns on 1080p/720p TVs, fitting the 5–7 posters-per-row target).
- Each poster card displays bounded `RGB_565` `180x260` artwork (`posterRequestOptions`), release year badge, quality badge (`4K UHD`, `1080p`, `HEVC`, `HD`), favorite star, title, category subtitle, and playback progress bar.
- Added `showMovieDetailModal()` with Resume Watching, Play from Beginning, Add/Remove Favorites, and Related Movies from the same provider category.

## 4. Advanced Series Library with Season & Episode Browser
- Extended `XtreamRepository.kt` with `fetchSeriesCatalog()` (`get_series_categories` + `get_series`) and `fetchSeriesEpisodes()` (`get_series_info`), and added M3U `SxxExx` series episode grouping (`MediaCatalogEngine.groupSeriesCatalog`).
- Added `showSeriesDetailModal()` with Season selector, Episode list with duration/progress badges, **Resume Watching**, **Next Episode**, and per-episode progress persistence.

## 5. Unified Global Search & Personalization
- Added `showUnifiedSearchDialog()` and `showUnifiedSearchResultsModal()` to search across Live TV channels, Movies, Series, Categories, Favorites, and Recently Watched items with persistent search history (`getSearchHistory`, `addSearchHistoryQuery`, `clearSearchHistory`).
- Added independent Movie and Series Episode progress persistence (`savePlaybackProgress`, `getPlaybackProgress`, `getContinueWatchingEntries`, `clearPlaybackProgress`) in `ProfileStore.kt` and automatic 8-second progress checkpointing during playback.

## 6. Upgraded 4D Vector Icon System & Poster Card Selector
- Added 7 new vector/selector drawables: `ic_3d_home.xml`, `ic_3d_movies.xml`, `ic_3d_series.xml`, `ic_3d_history.xml`, `ic_3d_network.xml`, `ic_3d_play.xml`, and `bg_poster_card_4d.xml` (total 55 drawables).

## 7. Adaptive Channel Prefetching, Performance Modes & Benchmark Instrumentation
- Added `PerformanceMode` (*Smart Balanced Mode*, *Fast Zapping Mode*, *Low Memory Mode*, *Network Saver Mode*) with D-Pad navigation speed adaptation in `StreamPreFetcher.scheduleFocusPrefetch()`.
- Added `ZapBenchmarkMetrics` in `PlayerActivity.kt` and `StreamPreFetcher.kt` to measure real-time *Key-Press to Selection*, *Selection to Preparation*, *Selection to First Video Frame*, *Channel Switch Completion*, *Last Buffering Duration*, *Prefetch Hit Rate %*, and *Failed Prefetch Rate %*.
- Improved `onPlayerError` retry policy in `PlayerActivity.kt` with bounded exponential backoff (`900ms`, `1800ms`, `3200ms`) and fast stop on permanent HTTP `401`/`403`/`404` failures.

## 8. GitHub Actions Workflow & Verification Suite
- Updated `.github/workflows/build_apk.yml` and `StreamX_GitHub_Actions_build_apk.yml` to run `python3 scripts/verify_project.py`, `testDebugUnitTest`, `lintDebug`, `assembleDebug`, and `assembleRelease`, validate APK archives via `unzip -t`, and upload both Release (`StreamX-Media3-Pro-v18.0-Next-Gen-Ultra-Extreme-512MB.apk`) and Debug APK artifacts.
- Expanded `M3uParserTest.kt` and `scripts/verify_project.py` to test all new v18.0 features.
