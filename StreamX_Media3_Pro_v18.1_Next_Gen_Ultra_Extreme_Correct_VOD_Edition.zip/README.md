# StreamX Media3 Pro — v18.1 Next-Generation Ultra Extreme Correct VOD Edition

**StreamX Media3 Pro v18.1 (`versionCode = 181`, `versionName = "18.1"`, package `com.harindra.iptvpro`)** is an in-place upgrade of the supplied **v18.0 Next-Generation Ultra Extreme Edition** project. All 102 original files, all 58 original view IDs (+ 3 new VOD sidebar/clock/sort IDs = 61 total IDs), all 55 4D Crystal drawables, Media3 1.11.1 Direct-RAM playback engine, SXB2 binary cache, XMLTV EPG parser, Xtream dual-stream `.m3u8`/`.ts` failover, AES-256-GCM encrypted profile store, salted SHA-256 parental PIN lock, and 512 MB RAM guard are preserved intact.

## What's New in v18.1 — Correct VOD Separation & Reference-Matched Experience

1. **Strict Source-Aware Content Separation (`ContentSourceType`):**
   - Eliminates all heuristic name/category/URL mixing between Live TV, Movies, and Series:
     - `M3U_LIVE`: Every entry imported from an M3U/M3U8 playlist is strictly assigned `ContentSourceType.M3U_LIVE` and stays in **LIVE TV** — even if named `"Bollywood Movies 24x7"`, `"Hollywood Action Movies"`, `"TMKOC 24x7"`, `"Web Series 24x7"`, or using `.mp4`/`.mkv` URLs or `group-title="Movies"` / `"Series"`. For M3U-only profiles, **MOVIES** and **SERIES** display a clean empty state explaining that VOD catalogs require an Xtream Codes account.
     - `XTREAM_LIVE`: Loaded exclusively from `player_api.php?action=get_live_categories` and `action=get_live_streams` into `allChannels` (cached under `live_<scope>`).
     - `XTREAM_VOD_MOVIE`: Loaded exclusively from `player_api.php?action=get_vod_categories`, `action=get_vod_streams`, and `action=get_vod_info` into `vodMoviesCatalog` (cached under `vod_<scope>`).
     - `XTREAM_SERIES` / `XTREAM_SERIES_EPISODE`: Loaded exclusively from `player_api.php?action=get_series_categories`, `action=get_series`, and `action=get_series_info` into `seriesCatalogGroups` (cached under `series_<scope>`).
   - Loading Movies or Series never overwrites or pollutes the active Live TV channel list (`allChannels`).
2. **Reference-Matched Movies & Series Interface (Matching Screenshots `25369.jpg`..`25381.jpg`):**
   - **Left VOD Category Sidebar (`vodCategorySidebarRecycler`):** Displays `FAVORITES`, `RECENTLY ADDED`, `CONTINUE WATCHING`, `ALL MOVIES` / `ALL SERIES`, and exact provider categories with item counts in parentheses (e.g., `BOLLYWOOD (2025-2026) (297)`, `PAK: HUM TV (224)`).
   - **Top VOD Bar:** Displays live clock & date (`tvVodLiveClockDate`), active category heading (`tvVodGridHeaderTitle`), `Continue Watching`, `★ Watchlist`, `↓ OLD/NEW • A-Z` sort button (`btnVodSortOrder`), `Sync VOD`, and `Live TV` button.
   - **Right 5-Column Poster Grid (`vodPosterRecycler`):** Displays 5 poster cards per row on Android TV with bounded `RGB_565` thumbnails (`180x260`, or `144x210` in Low-Memory Mode), title + year footer, watchlist star, and resume progress bar.
   - **Movie Details Screen (`presentMovieDetailOverlayDialog`):** Left movie poster, right metadata column (Title + Year, `★★★★★ (rating)` when available, release date, duration, genre, cast, plot, director), and two primary action buttons: **`TRAILER`** (plays genuine trailer URL or shows `"Trailer unavailable"`) and **`PLAY MOVIE`** (plus Resume Movie, Start from Beginning, and Watchlist toggle).
   - **Series Details Screen (`presentSeriesDetailOverlayDialog`):** Series poster & metadata header, **`SEASON 1`, `SEASON 2`...** selector pills, Watchlist toggle, Resume button, and scrollable episode rows (`HURMAT (2026) - S01E12` / `EPISODE NO: 12   SEASON: 1`).
3. **Five Additional Premium Features (Section 17):**
   - **17A. Smart Continue Watching:** Per-account isolated progress for Movies and Series Episodes only (Live TV excluded; >=95% marks completed).
   - **17B. Universal Smart Search:** Searches Live TV, Movies, and Series independently with explicit `[LIVE TV]`, `[MOVIE]`, `[SERIES]` badges; M3U-only accounts search Live TV only.
   - **17C. Personal Watchlist:** Per-account isolated Watchlists for Movies and Series (`toggleMovieWatchlist`, `toggleSeriesWatchlist`).
   - **17D. Smart Auto Next Episode:** Detects near-end/completion of a Series episode, resolves the genuine next episode (`MediaCatalogEngine.findNextEpisodeInSeries`), presents an 8-second countdown dialog with Cancel and Play Immediately options, and includes an enable/disable setting.
   - **17E. Smart Low-Memory Mode:** Integrated with `PerformanceMode.LOW_MEMORY` (`144x210` `RGB_565` posters, reduced animations, conservative cache bounds, preserves active Media3 playback).
